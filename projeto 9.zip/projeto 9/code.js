var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","dfc53be7-786c-4305-b8eb-81fa595e9903","47fade86-5bd1-4789-87af-896fb1433a7b","043deebf-64b8-4795-be8d-db5055414f2f","c4e310e0-8174-4127-a46e-0cbcc94b488b","01b7e996-1e7b-4bc7-bc6a-b3c633cb33bf","d85adcda-2387-4c4a-af8b-eafdb1171ae0","12201357-1aca-4fbd-8a79-0c8dc2fe45d3","d0dbb803-6141-4aeb-8018-2d3e4c82004f","872f94cd-9ee9-4aa1-9351-f7bf9bcc4ed4","58fd66ca-d0bc-40e9-a3b4-3ec784273c16","91b051f0-8d38-47a8-a241-77e2d5652e3f"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"zYwL7pMTBgE0nTalao7jWxmyUvLv.1nE","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"GH3DsRKPkKRil9g7oIUebZQDKIgfBCCS","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"dfc53be7-786c-4305-b8eb-81fa595e9903":{"name":"enemy12","sourceUrl":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png","frameSize":{"x":320,"y":254},"frameCount":1,"looping":true,"frameDelay":2,"version":"xasculQGiYxBV79ltD_0E79ZRIexdPdZ","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":320,"y":254},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png"},"47fade86-5bd1-4789-87af-896fb1433a7b":{"name":"enemy24","sourceUrl":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png","frameSize":{"x":355,"y":241},"frameCount":1,"looping":true,"frameDelay":2,"version":"dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":355,"y":241},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png"},"043deebf-64b8-4795-be8d-db5055414f2f":{"name":"enemy34","sourceUrl":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png","frameSize":{"x":388,"y":388},"frameCount":1,"looping":true,"frameDelay":2,"version":"YSis4_lex43su6FLaL__bhoag4eHAl8D","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":388},"rootRelativePath":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"6PBf.ifNBvIJ7G_IBM45b9CISWTfxbzF","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"01b7e996-1e7b-4bc7-bc6a-b3c633cb33bf":{"name":"papelsonic","sourceUrl":"assets/v3/animations/oqbeMyrZxFQbk3pM--srF8-A39GKbEhIQRcekgioHJ0/01b7e996-1e7b-4bc7-bc6a-b3c633cb33bf.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":4,"version":"1eD4eIxvk3PjqsSbCf3yBj6xh2OPo_a5","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/v3/animations/oqbeMyrZxFQbk3pM--srF8-A39GKbEhIQRcekgioHJ0/01b7e996-1e7b-4bc7-bc6a-b3c633cb33bf.png"},"d85adcda-2387-4c4a-af8b-eafdb1171ae0":{"name":"sonic","sourceUrl":"assets/v3/animations/oqbeMyrZxFQbk3pM--srF8-A39GKbEhIQRcekgioHJ0/d85adcda-2387-4c4a-af8b-eafdb1171ae0.png","frameSize":{"x":86,"y":86},"frameCount":1,"looping":true,"frameDelay":4,"version":"0KWnIOsiyWREjiaZ0SPJDfXZyl0PN03g","loadedFromSource":true,"saved":true,"sourceSize":{"x":86,"y":86},"rootRelativePath":"assets/v3/animations/oqbeMyrZxFQbk3pM--srF8-A39GKbEhIQRcekgioHJ0/d85adcda-2387-4c4a-af8b-eafdb1171ae0.png"},"12201357-1aca-4fbd-8a79-0c8dc2fe45d3":{"name":"sonic1","sourceUrl":"assets/v3/animations/oqbeMyrZxFQbk3pM--srF8-A39GKbEhIQRcekgioHJ0/12201357-1aca-4fbd-8a79-0c8dc2fe45d3.png","frameSize":{"x":225,"y":225},"frameCount":1,"looping":true,"frameDelay":4,"version":"e0Dkles9PpMv4ti6iVcr4msYKhpHv6tD","loadedFromSource":true,"saved":true,"sourceSize":{"x":225,"y":225},"rootRelativePath":"assets/v3/animations/oqbeMyrZxFQbk3pM--srF8-A39GKbEhIQRcekgioHJ0/12201357-1aca-4fbd-8a79-0c8dc2fe45d3.png"},"d0dbb803-6141-4aeb-8018-2d3e4c82004f":{"name":"sonic21","sourceUrl":"assets/v3/animations/oqbeMyrZxFQbk3pM--srF8-A39GKbEhIQRcekgioHJ0/d0dbb803-6141-4aeb-8018-2d3e4c82004f.png","frameSize":{"x":225,"y":225},"frameCount":1,"looping":true,"frameDelay":4,"version":"MKKGnLkEyls.W8dJTXkImTVOvpNvcfCz","loadedFromSource":true,"saved":true,"sourceSize":{"x":225,"y":225},"rootRelativePath":"assets/v3/animations/oqbeMyrZxFQbk3pM--srF8-A39GKbEhIQRcekgioHJ0/d0dbb803-6141-4aeb-8018-2d3e4c82004f.png"},"872f94cd-9ee9-4aa1-9351-f7bf9bcc4ed4":{"name":"enemy","sourceUrl":"assets/v3/animations/QWRBQuqpA-oYyDJRHIYBp51uTyLkR6bpzz0nmqpdNDw/872f94cd-9ee9-4aa1-9351-f7bf9bcc4ed4.png","frameSize":{"x":222,"y":227},"frameCount":1,"looping":true,"frameDelay":4,"version":"IQXjoBmCPFyZ.jjIuCfipY1SGwSny6R2","loadedFromSource":true,"saved":true,"sourceSize":{"x":222,"y":227},"rootRelativePath":"assets/v3/animations/QWRBQuqpA-oYyDJRHIYBp51uTyLkR6bpzz0nmqpdNDw/872f94cd-9ee9-4aa1-9351-f7bf9bcc4ed4.png"},"58fd66ca-d0bc-40e9-a3b4-3ec784273c16":{"name":" eggman","sourceUrl":"assets/v3/animations/M8T8Qh0CouKszB3POFSkKs9qH4ScEhhfl3UZFqInW5k/58fd66ca-d0bc-40e9-a3b4-3ec784273c16.png","frameSize":{"x":234,"y":215},"frameCount":1,"looping":true,"frameDelay":4,"version":"2V3b2cK7uHA9WAkarmAR2LlwUOdEi.aK","loadedFromSource":true,"saved":true,"sourceSize":{"x":234,"y":215},"rootRelativePath":"assets/v3/animations/M8T8Qh0CouKszB3POFSkKs9qH4ScEhhfl3UZFqInW5k/58fd66ca-d0bc-40e9-a3b4-3ec784273c16.png"},"91b051f0-8d38-47a8-a241-77e2d5652e3f":{"name":"shadow","sourceUrl":"assets/v3/animations/M8T8Qh0CouKszB3POFSkKs9qH4ScEhhfl3UZFqInW5k/91b051f0-8d38-47a8-a241-77e2d5652e3f.png","frameSize":{"x":178,"y":283},"frameCount":1,"looping":true,"frameDelay":4,"version":"RcZQoFUktgLuVdXfFw2ARUCmCbVYLoOD","loadedFromSource":true,"saved":true,"sourceSize":{"x":178,"y":283},"rootRelativePath":"assets/v3/animations/M8T8Qh0CouKszB3POFSkKs9qH4ScEhhfl3UZFqInW5k/91b051f0-8d38-47a8-a241-77e2d5652e3f.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var papelsonic = createSprite(200,200);
 papelsonic.setAnimation("papelsonic");
var hero = createSprite(200,345,200,345);
hero.shapeColor="red";

var enemy = createSprite(200,250,40,35);
enemy.shapeColor="red";

var  eggman=createSprite(200,150,50,10);
 eggman.shapeColor="red";

var shadow = createSprite(200,50,10,10);
shadow.shapeColor="red";

var net = createSprite(200,5,200,20);
net.shapeColor="red";

var goal =0;
var death = 0;

hero.setAnimation("sonic21");
hero.scale=.2;
enemy.setAnimation("enemy");
enemy.scale=.1;
 eggman.setAnimation(" eggman");
 eggman.scale=.1;
shadow.setAnimation("shadow");
shadow.scale=.1;

enemy.setVelocity(-10,0);
 eggman.setVelocity(10,0);
shadow.setVelocity(-10,0);


function draw() {
  
//plano de fundo(b);

createEdgeSprites();




enemy.bounceOff(edges);
 eggman.bounceOff(edges);
shadow.bounceOff(edges);

if(keyDown(UP_ARROW)){
  hero.y=hero.y-3;
}

if(keyDown(DOWN_ARROW)){
  hero.y=hero.y+3;
}

if(keyDown(LEFT_ARROW)){
  hero.x=hero.x-3;
}

if(keyDown(RIGHT_ARROW)){
  hero.x=hero.x+3;
}

if(hero.isTouching(enemy)|| hero.isTouching( eggman)|| hero.isTouching(shadow)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3");
  hero.x=200;
  hero.y=350;
  death = death+1;
}
if(hero.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3");
  hero.x=200;
  hero.y=345;
  goal=goal+1;
}
textSize(20);
  fill("blue");
  text("Objetivos:"+goal,320,350);
  

textSize(20);
  fill("blue");
  text("mortes:"+death,20,350);
  
drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
